﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace BeautyShop
{
    public partial class AppointmentWindow : Window
    {
        private BeautyShopEntities _context = new BeautyShopEntities();
        public AppointmentWindow(int clientId)
        {
            InitializeComponent();
            ClientId = clientId;
            LoadCategories();
            DatePickerControl.SelectedDate = DateTime.Today;
        }

        public int ClientId { get; }

        private void LoadCategories()
        {
            var categories = _context.ServiceCategories.ToList();
            CategoryComboBox.ItemsSource = categories;
            CategoryComboBox.DisplayMemberPath = "Name";
            CategoryComboBox.SelectedValuePath = "CategoryID";
        }

        private void CategoryComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CategoryComboBox.SelectedValue is int catId)
            {
                var services = _context.Services
                    .Where(s => s.CategoryID == catId)
                    .ToList();
                ServiceComboBox.ItemsSource = services;
                ServiceComboBox.DisplayMemberPath = "Name";
                ServiceComboBox.SelectedValuePath = "ServiceID";
            }
        }

        private void ServiceComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ServiceComboBox.SelectedValue is int srvId)
            {
          
                var employees = _context.Employees
                    .Where(emp => emp.Services.Any(s => s.ServiceID == srvId))
                    .ToList();
                EmployeeComboBox.ItemsSource = employees;
                EmployeeComboBox.DisplayMemberPath = "LastName";
                EmployeeComboBox.SelectedValuePath = "EmployeeID";
            }
        }

        private void DatePickerControl_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadAvailableTimes();
        }

        private void LoadAvailableTimes()
        {
            TimeComboBox.ItemsSource = null;
            if (EmployeeComboBox.SelectedValue is int empId && DatePickerControl.SelectedDate.HasValue)
            {
                var date = DatePickerControl.SelectedDate.Value;
                var schedule = _context.Schedules
                    .Where(s => s.EmployeeID == empId && s.Date == date && s.IsWorkingDay == true)
                    .FirstOrDefault();
                if (schedule != null)
                {
                    var times = new System.Collections.Generic.List<string>();
                    for (var t = schedule.StartTime; t < schedule.EndTime; t = t.Add(TimeSpan.FromMinutes(30)))
                    {
                        var dt = date + t;
                        bool occupied = _context.Appointments
                            .Any(a => a.EmployeeID == empId && a.DateTime == dt);
                        if (!occupied)
                            times.Add(t.ToString(@"hh\:mm"));
                    }
                    TimeComboBox.ItemsSource = times;
                }
            }
        }

        private void BookButton_Click(object sender, RoutedEventArgs e)
        {
            if (ServiceComboBox.SelectedValue is int srvId &&
                EmployeeComboBox.SelectedValue is int empId &&
                DatePickerControl.SelectedDate.HasValue)
            {
                var date = DatePickerControl.SelectedDate.Value.Date;
                var start = date.AddHours(10);
                var end = start.AddHours(1);

                var appt = new Appointments
                {
                    ClientID = ClientId,
                    ServiceID = srvId,
                    EmployeeID = empId,
                    DateTime = start,
                    EndDateTime = end,
                    Status = "Запланировано",
                    CreatedAt = DateTime.Now
                };
                _context.Appointments.Add(appt);
                _context.SaveChanges();

                MessageBox.Show("Запись успешно создана!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите услугу, мастера и дату.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
